package sal.collegenotes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class department1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department1);
    }

    public void onsub1(View view) {

        Intent intent = new Intent("sal.collegenotes.sub1");
        startActivity(intent);
    }
    public void onsub2(View view) {

        Intent intent = new Intent("sal.collegenotes.sub1");
        startActivity(intent);
    }
    //assign upto n click operations for your app as u need
    public void onsubn(View view) {

        Intent intent = new Intent("sal.collegenotes.sub1");
        startActivity(intent);
    }
}
