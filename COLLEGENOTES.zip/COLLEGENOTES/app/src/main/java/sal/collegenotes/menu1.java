package sal.collegenotes;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class menu1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu1);
    }
    //ive assigned everything to department as this is a demo app,u can assign it to your need
    //when you are working on your projects
    public void ondep1click(View view) {

        Intent intent = new Intent("sal.collegenotes.department1");
        startActivity(intent);
    }
    public void ondep2click(View view) {

        Intent intent = new Intent("sal.collegenotes.department1");
        startActivity(intent);
    }
    //assign upto n click operations for your app as u need
    public void ondepnclick(View view) {

        Intent intent = new Intent("sal.collegenotes.department1");
        startActivity(intent);
    }

}
